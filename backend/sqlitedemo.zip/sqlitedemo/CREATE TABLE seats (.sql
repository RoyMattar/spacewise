CREATE TABLE seats (
    seat_id INT AUTO_INCREMENT PRIMARY KEY,
    space_id INT NOT NULL,
    name VARCHAR(50) NOT NULL, -- e.g., "A1"
    type VARCHAR(50), -- e.g., "table", "armchair"
    facilities JSON, -- Store facilities as JSON (e.g., { "outlets": true })
    status ENUM('available', 'reserved', 'unavailable') NOT NULL,
    FOREIGN KEY (space_id) REFERENCES spaces (space_id) ON DELETE CASCADE
);

INSERT INTO seats (space_id, name, type, facilities, status) VALUES
(1, 'A1', 'Chair', '{"outlets": true, "lamp": true}', 'available'),
(1, 'A2', 'Table', '{"outlets": false, "lamp": true}', 'reserved'),
(2, 'B1', 'Armchair', '{"outlets": true}', 'available'),
(3, 'C1', 'Couch', '{"outlets": false, "lamp": false}', 'unavailable');

SELECT * FROM seats;