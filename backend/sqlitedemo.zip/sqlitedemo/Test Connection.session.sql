INSERT INTO institutions (
    institution_id,
    name,
    bio,
    address,
    opening_hours,
    admin_id
  )
VALUES (
    institution_id:int,
    'name:varchar',
    'bio:text',
    'address:varchar',
    'opening_hours:varchar',
    admin_id:int
  );CREATE TABLE users (
    user_id INT AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(50) NOT NULL UNIQUE,
    password_hash VARCHAR(255) NOT NULL,
    role ENUM('admin', 'student') NOT NULL
);

INSERT INTO users (username, password_hash, role) VALUES
('admin1', 'hashed_password1', 'admin'),
('student1', 'hashed_password2', 'student'),
('student2', 'hashed_password3', 'student');

SELECT * FROM users;INSERT INTO institutions (
    institution_id,
    name,
    bio,
    address,
    opening_hours,
    admin_id
  )
VALUES (
    institution_id:int,
    'name:varchar',
    'bio:text',
    'address:varchar',
    'opening_hours:varchar',
    admin_id:int
  );