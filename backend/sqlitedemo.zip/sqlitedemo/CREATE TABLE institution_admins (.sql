CREATE TABLE institution_admins (
    admin_id INT PRIMARY KEY, -- Matches `user_id` in `users`
    institution_id INT NOT NULL,
    FOREIGN KEY (admin_id) REFERENCES users (user_id) ON DELETE CASCADE,
    FOREIGN KEY (institution_id) REFERENCES institutions (institution_id) ON DELETE CASCADE
);

INSERT INTO institution_admins (admin_id, institution_id) VALUES
(1, 1),
(1, 2);

SELECT * FROM institution_admins;
