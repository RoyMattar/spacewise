CREATE TABLE spaces (
    space_id INT AUTO_INCREMENT PRIMARY KEY,
    institution_id INT NOT NULL,
    name VARCHAR(100) NOT NULL,
    layout TEXT, -- Stores URL or file path
    FOREIGN KEY (institution_id) REFERENCES institutions (institution_id) ON DELETE CASCADE
);

INSERT INTO spaces (institution_id, name, layout) VALUES
(1, 'Library Room A', 'https://example.com/layouts/library-room-a.png'),
(1, 'Library Room B', 'https://example.com/layouts/library-room-b.png'),
(2, 'Startup Lounge', 'https://example.com/layouts/startup-lounge.png');

SELECT * FROM spaces;

