CREATE TABLE institutions (
    institution_id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    bio TEXT,
    address VARCHAR(255) NOT NULL,
    opening_hours VARCHAR(50),
    admin_id INT NOT NULL,
    FOREIGN KEY (admin_id) REFERENCES users (user_id) ON DELETE CASCADE
);

INSERT INTO institutions (name, bio, address, opening_hours, admin_id) VALUES
('Library Central', 'Main library of the city', '123 Library Street', '9 AM - 8 PM', 1),
('Co-working Space A', 'Modern space for startups', '456 Startup Lane', '24/7', 1);

SELECT * FROM institutions;

