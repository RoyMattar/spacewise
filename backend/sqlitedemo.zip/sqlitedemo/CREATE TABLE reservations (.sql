CREATE TABLE reservations (
    reservation_id INT AUTO_INCREMENT PRIMARY KEY,
    space_id INT NOT NULL,
    seat_id INT NOT NULL,
    user_id INT NOT NULL,
    start_time DATETIME NOT NULL,
    end_time DATETIME NOT NULL,
    status ENUM('active', 'expired', 'cancelled') NOT NULL,
    FOREIGN KEY (space_id) REFERENCES spaces (space_id) ON DELETE CASCADE,
    FOREIGN KEY (seat_id) REFERENCES seats (seat_id) ON DELETE CASCADE,
    FOREIGN KEY (user_id) REFERENCES users (user_id) ON DELETE CASCADE
);

INSERT INTO reservations (space_id, seat_id, user_id, start_time, end_time, status) VALUES
(1, 1, 2, '2024-12-01 10:00:00', '2024-12-01 12:00:00', 'active'),
(1, 2, 3, '2024-12-01 13:00:00', '2024-12-01 14:00:00', 'cancelled'),
(3, 4, 2, '2024-12-02 15:00:00', '2024-12-02 17:00:00', 'expired');

SELECT * FROM reservations;