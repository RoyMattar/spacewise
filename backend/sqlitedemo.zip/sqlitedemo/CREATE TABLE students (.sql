CREATE TABLE students (
    student_id INT PRIMARY KEY, -- Matches `user_id` in `users`
    FOREIGN KEY (student_id) REFERENCES users (user_id) ON DELETE CASCADE
);

INSERT INTO students (student_id) VALUES
(2),
(3);

SELECT * FROM students;
