INSERT INTO reservations (
    reservation_id,
    space_id,
    seat_id,
    user_id,
    start_time,
    end_time,
    status
  )
VALUES (
    reservation_id:int,
    space_id:int,
    seat_id:int,
    user_id:int,
    'start_time:datetime',
    'end_time:datetime',
    'status:enum'
  );

SELECT * FROM reservations;

INSERT INTO reservations (space_id, seat_id, user_id, start_time, end_time, status)
VALUES (2, 2, 1, '2025-02-02 9:00', '2025-02-02 12:30', 'Active');

SELECT r.reservation_id, r.seat_id, r.start_time, r.end_time, r.status
FROM reservations r
JOIN seats s ON r.seat_id = s.seat_id
WHERE r.user_id = 2;

UPDATE reservations
SET 
    start_time = COALESCE('2025-01-02 9:30', start_time),
    end_time = COALESCE('2025-01-02 12:30', end_time),
    status = COALESCE('Cancelled', status)
WHERE reservation_id = 3;

UPDATE reservations
SET status = 'Cancelled'
WHERE reservation_id = 4;