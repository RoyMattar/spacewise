INSERT INTO seats (
    seat_id,
    space_id,
    name,
    type,
    facilities,
    status
  )
VALUES (
    seat_id:int,
    space_id:int,
    'name:varchar',
    'type:varchar',
    'facilities:json',
    'status:enum'
  );

SELECT * FROM seats;

INSERT INTO seats (space_id, name, type, facilities, status)
VALUES (2, 'C2', 'Chair', '["Outlet", "Lamp"]', 'Available');

SELECT seat_id FROM seats WHERE name = 'C2' AND space_id = 2;

UPDATE seats
SET type = 'Table',
    facilities = '["Outlet"]',
    status = 'Unavailable'
WHERE space_id = 3 AND seat_id = 4;

DELETE FROM seats WHERE space_id = 1 AND seat_id = 1;


