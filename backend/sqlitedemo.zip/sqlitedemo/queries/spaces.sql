INSERT INTO spaces (space_id, institution_id, name, layout)
VALUES (
    space_id:int,
    institution_id:int,
    'name:varchar',
    'layout:text'
  );

SELECT * FROM spaces;

INSERT INTO spaces(name, layout)
VALUES (
    'Library Room A', 'base64_encoded_image'
);

SELECT space_id FROM spaces WHERE name = 'Library Room A' AND institution_id = 1;

SELECT space_id, name, layout FROM spaces WHERE institution_id = 1;

SELECT space_id, name, layout FROM spaces WHERE institution_id = 1 AND space_id = 1;

UPDATE spaces
SET name = 'Updated Room Name',
    layout = 'updated.png'
WHERE institution_id = 2 AND space_id = 3;

DELETE FROM spaces WHERE institution_id = 1 AND space_id = 2;
