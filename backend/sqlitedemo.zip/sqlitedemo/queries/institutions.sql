INSERT INTO institutions (
    institution_id,
    name,
    bio,
    address,
    opening_hours,
    admin_id
  )
VALUES (
    institution_id:int,
    'name:varchar',
    'bio:text',
    'address:varchar',
    'opening_hours:varchar',
    admin_id:int
  );

SELECT * FROM institutions;

INSERT INTO institutins (institution_id, bio, address, opening_hours, admin_id)
VALUES (1, 'Library Central', 'Main library of the city', '9 AM - 8 PM', 1);

SELECT institution_id FROM institutions WHERE name = 'Library Central';

SELECT institution_id, name, bio, address, opening_hours FROM institutions;

SELECT i.institution_id, i.name, i.bio, i.address, i.opening_hours AS admin_username
FROM institutions i
JOIN institution_admins ia ON i.institution_id = ia.institution_id
JOIN users u ON ia.admin_id = u.user_id
WHERE i.institution_id = 1;


UPDATE institutions
SET bio = 'Updated bio for the institution',
    address = 'New Address Street',
    opening_hours = '8 AM - 6 PM'
WHERE institution_id = 2;

DELETE FROM institutions WHERE institution_id = 1;
