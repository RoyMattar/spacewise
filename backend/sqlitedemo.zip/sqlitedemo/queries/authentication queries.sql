INSERT INTO users (user_id, username, password_hash, role)
VALUES (
    user_id:int,
    'username:varchar',
    'password_hash:varchar',
    'role:enum'
  );

SELECT * FROM users;

INSERT INTO users (username, password_hash, role)
VALUES (
  'admin123', 'securepassword', 'admin'
);

SELECT user_id FROM users WHERE username = 'admin123';

SELECT user_id, role 
FROM users 
WHERE username = 'admin123' AND password_hash = 'securepassword';


